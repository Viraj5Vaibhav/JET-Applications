define([], function() {
  'use strict';

  var FlowModule = function FlowModule() {};

  return FlowModule;
});