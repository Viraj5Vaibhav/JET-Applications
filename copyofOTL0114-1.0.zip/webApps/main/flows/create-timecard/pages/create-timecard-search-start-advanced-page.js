/**
 * Copyright (c)2020, 2021, Oracle and/or its affiliates.
 * Licensed under The Universal Permissive License (UPL), Version 1.0
 * as shown at https://oss.oracle.com/licenses/upl/
 */
define(['knockout', 'ojs/ojflattenedtreedataproviderview', 'ojs/ojarraytreedataprovider','ojs/ojarraydataprovider',
  'ojs/ojknockouttemplateutils', 'ojs/ojkeyset', 'ojs/ojlistitemlayout'],
  function (ko, FlattenedTreeDataProviderView, ArrayTreeDataProvider, ArrayDataProvider, KnockoutTemplateUtils, ojkeyset_1) {
    'use strict';

    var PageModule = function PageModule() {
    };

    PageModule.prototype.getKeySet = function(){
      return new ojkeyset_1.KeySetImpl(["a", "b", "c"]);
    };

    PageModule.prototype.getDataForRowExpander = function(jsonData){
      var observable =  ko.observable(new FlattenedTreeDataProviderView(new ArrayTreeDataProvider(jsonData)));
      console.log(observable);
      return observable;
    };

    PageModule.prototype.getArrayDataProvider = function(arr){
      return new ArrayDataProvider(arr,{
        keyAttributes: "task_id"
      });
    };

    PageModule.prototype.isValueAlreadyExists = function(adpData, rec_number){
      return adpData.some(el => el.rec_number == rec_number);
    };
    
    return PageModule;
  });
