define([], function() {
  'use strict';

  var PageModule = function PageModule() {};

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.create_href_tags = function (arg1) {
    let output = [];
    for (let i = 0; i < arg1.Items.length; i++) {
      output[i] = "location.href='#" + i + "';";
    }
    return output;
  };

  return PageModule;
});
