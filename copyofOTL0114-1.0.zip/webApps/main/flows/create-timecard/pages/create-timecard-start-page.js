define([], function() {
  'use strict';

  var PageModule = function PageModule() {};

  PageModule.prototype.addBtnToLOV = function(ArrData){
    ArrData.push({
                    "template_id": -999,
                    "template_name": "SEE ALL",
                    "template_description": "SEE ALL BUTTON",
                    "total_hours": 0
                });
                
    return ArrData;
  };

  return PageModule;
});
