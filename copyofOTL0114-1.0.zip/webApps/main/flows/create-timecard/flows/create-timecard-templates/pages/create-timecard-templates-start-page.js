define([], function() {
  'use strict';

  var PageModule = function PageModule() {};

  PageModule.prototype.TotalHours = function(sun,mon){
    var total;
    total = +sun + +mon;
    return (total);
  };

  return PageModule;
});
