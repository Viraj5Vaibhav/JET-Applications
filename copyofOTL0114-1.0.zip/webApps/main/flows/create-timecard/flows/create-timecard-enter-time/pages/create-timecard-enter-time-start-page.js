define([], function() {
  'use strict';

  var PageModule = function PageModule() {};

  PageModule.prototype.isSummaryRowExists = function(arr){
    return arr.some(item => item.time_entry_dtl_id === -999999);
  };

  PageModule.prototype.getSummaryRow = function(arr){
    var time6Total = 0 , time7Total = 0, time1Total = 0, time2Total = 0, time3Total = 0, time4Total = 0, time5Total = 0;
    for(var i=0; i<arr.length; i++){
      
      if(arr[i].time_entry_dtl_id !== -999999){
        time6Total += Number(arr[i].time6_measure);
        time7Total += Number(arr[i].time7_measure);
        time1Total += Number(arr[i].time1_measure);
        time2Total += Number(arr[i].time2_measure);
        time3Total += Number(arr[i].time3_measure);
        time4Total += Number(arr[i].time4_measure);
        time5Total += Number(arr[i].time5_measure);
      }
      
    }
    
    return {
        "summary":{
            "time_entry_dtl_id": -999999,
            "project_name": "Total Hours",
            "time6_measure": time6Total.toString(),
            "time7_measure": time7Total.toString(),
            "time1_measure": time1Total.toString(),
            "time2_measure": time2Total.toString(),
            "time3_measure": time3Total.toString(),
            "time4_measure": time4Total.toString(),
            "time5_measure": time5Total.toString()
        },
        "totalTime": (time6Total + time7Total + time1Total + time2Total + time3Total + time4Total + time5Total)
      };
  };

  PageModule.prototype.getCurrentDate = function(){
    var currentDate = new Date();
    var dd = currentDate.getDate();
    const monthNames = ["January", "February", "March", "April", "May", "June",
                          "July", "August", "September", "October", "November", "December"];
    var mm = currentDate.getMonth(); // Jan is 0
    var yy = currentDate.getFullYear();
    if (dd < 10) {
      dd = '0' + dd;
    }
    // if (mm < 10) {
    //   mm = '0' + mm;
    // }
    currentDate = monthNames[mm].toUpperCase() + ' ' + dd + ', ' + yy;
    return currentDate;
  };

  PageModule.prototype.getFormattedDate = function(dateString){
    var currentDate = new Date(dateString);
    var dd = currentDate.getDate();
    const monthNames = ["January", "February", "March", "April", "May", "June",
                          "July", "August", "September", "October", "November", "December"];
    var mm = currentDate.getMonth(); // Jan is 0
    var yy = currentDate.getFullYear();
    if (dd < 10) {
      dd = '0' + dd;
    }
    // if (mm < 10) {
    //   mm = '0' + mm;
    // }
    currentDate = monthNames[mm] + ' ' + dd + ', ' + yy;
    return currentDate;
  };

  PageModule.prototype.generateTimeRecordPayload = function (timecardTableDataADP) {
    var reporter_id = "100836169";
    var timeCardPayload={};
    console.log(JSON.stringify(timecardTableDataADP));
    for(var i=0;i<timecardTableDataADP.length-1;i++)
    {
      var timeRecordEvent = [], timeRecordEventAttribute = [], dates = [];
      var timeRecordEventRow = {},timeRecordEventAttributeRow = {};
      dates = getDatesBetweenDates(timecardTableDataADP[i].start_date,timecardTableDataADP[i].end_date);
      console.log("Dates : "+JSON.stringify(dates));
      console.log(JSON.stringify(timecardTableDataADP[i]));
      Object.assign(timeRecordEventAttributeRow,{
        ["attributeName"]:"PJC_PROJECT_ID",
        ["attributeValue"]:300003145417846
        //["attributeValue"]:timecardTableDataADP[i].project_id
      });
      timeRecordEventAttribute.push(timeRecordEventAttributeRow);
      timeRecordEventAttributeRow={};
      Object.assign(timeRecordEventAttributeRow,{
        ["attributeName"]:"PJC_PROJECT_UNIT",
        ["attributeValue"]:300002838051513
        //["attributeValue"]:timecardTableDataADP[i].pjc_project_unit
      });
      timeRecordEventAttribute.push(timeRecordEventAttributeRow);
      timeRecordEventAttributeRow={};
      Object.assign(timeRecordEventAttributeRow,{
        ["attributeName"]:"PJC_TASK_ID",
        //["attributeValue"]:timecardTableDataADP[i].task_id
        ["attributeValue"]:100002306349791
      });
      timeRecordEventAttribute.push(timeRecordEventAttributeRow);
      timeRecordEventAttributeRow={};
      Object.assign(timeRecordEventAttributeRow,{
        ["attributeName"]:"PWC_OTL_COUNTRIES_TM_ATT",
        ["attributeValue"]:300000000361907
        //["attributeValue"]:timecardTableDataADP[i].pwc_otl_countries_tm_att
      });
      timeRecordEventAttribute.push(timeRecordEventAttributeRow);
      timeRecordEventAttributeRow={};
      Object.assign(timeRecordEventAttributeRow,{
        ["attributeName"]:"PWC_OTL_ENGAGEMENT_PARTNER_ATT",
        ["attributeValue"]:"Singh, Jagdev"
        //["attributeValue"]:timecardTableDataADP[i].engagement_partner_name
      });
      timeRecordEventAttribute.push(timeRecordEventAttributeRow);
      timeRecordEventAttributeRow={};
      Object.assign(timeRecordEventAttributeRow,{
        ["attributeName"]:"PWC_OTL_PROJ_ORG_ATT",
        ["attributeValue"]:"MY TAX TP KUL"
        //["attributeValue"]:timecardTableDataADP[i].pwc_otl_proj_org_att
      });
      timeRecordEventAttribute.push(timeRecordEventAttributeRow);
      timeRecordEventAttributeRow={};
      Object.assign(timeRecordEventAttributeRow,{
        ["attributeName"]:"PJC_EXPENDITURE_TYPE_ID",
        ["attributeValue"]:300000003340335
        //["attributeValue"]:timecardTableDataADP[i].expenditure_type_hr_id
      });
      timeRecordEventAttribute.push(timeRecordEventAttributeRow);
      timeRecordEventAttributeRow={};
      Object.assign(timeRecordEventAttributeRow,{
        ["attributeName"]:"PJC_EXPENDITURE_TYPE_NAME",
        ["attributeValue"]:"300000003340335 - ST"
        //["attributeValue"]:timecardTableDataADP[i].expenditure_type_hr_name
      });
      timeRecordEventAttribute.push(timeRecordEventAttributeRow);
      timeRecordEventAttributeRow={};
      Object.assign(timeRecordEventAttributeRow,{
        ["attributeName"]:"PJC_SYSTEM_LINKAGE_FUNCTION",
        ["attributeValue"]:"ST"
        //["attributeValue"]:timecardTableDataADP[i].pjc_system_linkage_function
      });
      timeRecordEventAttribute.push(timeRecordEventAttributeRow);
      timeRecordEventAttributeRow={};
      Object.assign(timeRecordEventAttributeRow,{
        ["attributeName"]:"PayrollTimeType",
        ["attributeValue"]:"RS Reg Hours 03"
        //["attributeValue"]:timecardTableDataADP[i].payrolltimetype
      });
      timeRecordEventAttribute.push(timeRecordEventAttributeRow);
      timeRecordEventAttributeRow={};
      
      Object.assign(timeRecordEventRow,{
        ["timeRecordId"]: "",
        ["timeRecordVersion"]: "",
        ["startTime"]: dates[0],
        ["measure"]: timecardTableDataADP[i].time1_measure,
        ["reporterIdType"]: "PERSON",
        ["reporterId"]: reporter_id,
        ["crudStatusValue"]: "0",
        ["comment"]: timecardTableDataADP[i].time1_comments,
        ["operationType"]: "ADD",
        ["timeRecordEventAttribute"]:timeRecordEventAttribute
      });
      timeRecordEvent.push(timeRecordEventRow);
      timeRecordEventRow={};
      Object.assign(timeRecordEventRow,{
        ["timeRecordId"]: "",
        ["timeRecordVersion"]: "",
        ["startTime"]: dates[1],
        ["measure"]: timecardTableDataADP[i].time2_measure,
        ["reporterIdType"]: "PERSON",
        ["reporterId"]: reporter_id,
        ["crudStatusValue"]: "0",
        ["comment"]: timecardTableDataADP[i].time2_comments,
        ["operationType"]: "ADD",
        ["timeRecordEventAttribute"]:timeRecordEventAttribute
      });
      timeRecordEvent.push(timeRecordEventRow);
      timeRecordEventRow={};
      Object.assign(timeRecordEventRow,{
        ["timeRecordId"]: "",
        ["timeRecordVersion"]: "",
        ["startTime"]: dates[2],
        ["measure"]: timecardTableDataADP[i].time3_measure,
        ["reporterIdType"]: "PERSON",
        ["reporterId"]: reporter_id,
        ["crudStatusValue"]: "0",
        ["comment"]: timecardTableDataADP[i].time3_comments,
        ["operationType"]: "ADD",
        ["timeRecordEventAttribute"]:timeRecordEventAttribute
      });
      timeRecordEvent.push(timeRecordEventRow);
      timeRecordEventRow={};

      Object.assign(timeRecordEventRow,{
        ["timeRecordId"]: "",
        ["timeRecordVersion"]: "",
        ["startTime"]: dates[3],
        ["measure"]: timecardTableDataADP[i].time4_measure,
        ["reporterIdType"]: "PERSON",
        ["reporterId"]: reporter_id,
        ["crudStatusValue"]: "0",
        ["comment"]: timecardTableDataADP[i].time4_comments,
        ["operationType"]: "ADD",
        ["timeRecordEventAttribute"]:timeRecordEventAttribute
      });
      timeRecordEvent.push(timeRecordEventRow);
      timeRecordEventRow={};

      Object.assign(timeRecordEventRow,{
        ["timeRecordId"]: "",
        ["timeRecordVersion"]: "",
        ["startTime"]: dates[4],
        ["measure"]: timecardTableDataADP[i].time5_measure,
        ["reporterIdType"]: "PERSON",
        ["reporterId"]: reporter_id,
        ["crudStatusValue"]: "0",
        ["comment"]: timecardTableDataADP[i].time5_comments,
        ["operationType"]: "ADD",
        ["timeRecordEventAttribute"]:timeRecordEventAttribute
      });
      timeRecordEvent.push(timeRecordEventRow);
      timeRecordEventRow={};

      Object.assign(timeRecordEventRow,{
        ["timeRecordId"]: "",
        ["timeRecordVersion"]: "",
        ["startTime"]: dates[5],
        ["measure"]: timecardTableDataADP[i].time6_measure,
        ["reporterIdType"]: "PERSON",
        ["reporterId"]: reporter_id,
        ["crudStatusValue"]: "0",
        ["comment"]: timecardTableDataADP[i].time6_comments,
        ["operationType"]: "ADD",
        ["timeRecordEventAttribute"]:timeRecordEventAttribute
      });
      timeRecordEvent.push(timeRecordEventRow);
      timeRecordEventRow={};

      Object.assign(timeRecordEventRow,{
        ["timeRecordId"]: "",
        ["timeRecordVersion"]: "",
        ["startTime"]: dates[6],
        ["measure"]: timecardTableDataADP[i].time7_measure,
        ["reporterIdType"]: "PERSON",
        ["reporterId"]: reporter_id,
        ["crudStatusValue"]: "0",
        ["comment"]: timecardTableDataADP[i].time7_comments,
        ["operationType"]: "ADD",
        ["timeRecordEventAttribute"]:timeRecordEventAttribute
      });
      timeRecordEvent.push(timeRecordEventRow);
      timeRecordEventRow={};
      
    }
    Object.assign(timeCardPayload,{
        ["processInline"]: "Y",
        ["processMode"]: "TIME_SUBMIT",
        ["timeRecordEvent"]: timeRecordEvent
    });
    console.log("Final Payload: "+JSON.stringify(timeCardPayload));

    return timeCardPayload;
  };

  const getDatesBetweenDates = (startDate, endDate) => {
  let dates = [];
  //to avoid modifying the original date
  const theDate = new Date(startDate);
  while (theDate <= new Date(endDate)) {
    dates.push(new Date(theDate));
    theDate.setDate(theDate.getDate() + 1);
  }
  return dates;
};

  return PageModule;
});
