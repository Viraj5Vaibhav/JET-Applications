define(['ojs/ojpagingdataproviderview', 'ojs/ojarraydataprovider'], function(PagingDataProviderView, ArrayDataProvider) {
  'use strict';

  var PageModule = function PageModule() {};

  PageModule.prototype.TotalHours = function(time1_measure,time2_measure){
    var total;
    total = +time1_measure + +time2_measure;
    return (total);
  }

  /**
   *
   * @param {String} arg1
   * @return {String}
   */
  PageModule.prototype.paging_fxn = function (arg1) {
    return new PagingDataProviderView(new ArrayDataProvider(arg1, { idAttribute: 'id' }));
  };

  return PageModule;
});
