define([], function () {
  'use strict';

  var AppModule = function AppModule() {};

  AppModule.prototype.log = function(obj){
    console.log('PwC OTL Log');
    console.log(obj);
  };

  AppModule.prototype.showLoader = function() {
    if(document.getElementById("loader-shell")){
      document.getElementById("loader-shell").style.display = "block";
    }
  };

  AppModule.prototype.hideLoader = function() {
    if(document.getElementById("loader-shell")){
      document.getElementById("loader-shell").style.display = "none";
    }
  };

  AppModule.prototype.getCurrentWeekStartAndEndDate = function(){

    var date = new Date();
    var timezoneOffset = date.getMinutes() + date.getTimezoneOffset();
    var timestamp = date.getTime() + timezoneOffset * 1000;
    var correctDate = new Date(timestamp);
    
    correctDate.setUTCHours(0, 0, 0, 0);

    var first = correctDate.getDate() - correctDate.getDay() + 1; // First day is the day of the month - the day of the week + 2(as 1st day starts on Monday)
    var last = first + 6; // last day is the first day + 6

    var firstday = new Date(correctDate.setDate(first)).toISOString();
    var lastday = new Date(correctDate.setDate(last)).toISOString();

    return {
      "currentWeekEndDate":lastday,
      "currentWeekStartDate":firstday
    };
  };

  return AppModule;
});